package jsp.test;

public class test2 {
	String a="안녕 나는 test2 a야";
	String c="굿굿";
	public String getC() {
		return c;
	}

	public void setC(String c) {
		this.c = c;
	}

	public String getA() {
		return a;
	}

	public void setA(String a) {
		this.a = a;
	}
}
