package jsp.test;

public class test3 {
String d="ㅎㅇ";

public String getD() {
	return d;
}

public void setD(String d) {
	this.d = d;
}
}
