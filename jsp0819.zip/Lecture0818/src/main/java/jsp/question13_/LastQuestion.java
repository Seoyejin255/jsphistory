package jsp.question13_;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LastQuestion
 */
@WebServlet("/q16_/LastQuestion")
public class LastQuestion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public LastQuestion() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		session.setAttribute("id", request.getParameter("id"));
		session.setAttribute("pw", request.getParameter("pw"));
		session.setMaxInactiveInterval(10);
//		out.print("<html>");
//		out.print("<body>");
		out.print("<a href='index2.jsp'>index 2로 가기</a>");
//		out.print("</body>");
//		out.print("</html>");
	}

}
