package point;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Point {
	
	public String pointCheck(String nickname) {
			String point="";
		try {
			String jdbc_driver ="com.mysql.cj.jdbc.Driver";
			String dburl ="jdbc:mysql://localhost:3306/carrot?serverTimezone=UTC";
			String dbUser ="root";		String dbpasswd ="admin";
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from user where nickname ='"+nickname+"'");
			rs.next();
			point=rs.getString("point");
		}catch(Exception e) {
			
		}
		return point;
	}
	
	public void pointPlus10(String nickname) {
		try {
			String jdbc_driver ="com.mysql.cj.jdbc.Driver";
			String dburl ="jdbc:mysql://localhost:3306/carrot?serverTimezone=UTC";
			String dbUser ="root";		String dbpasswd ="admin";
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			st.executeUpdate("update user set point=point+10 where nickname='"+nickname+"'");
		}catch(Exception e) {
			
		}
	}
	public void pointPlus30(String nickname) {
		try {
			String jdbc_driver ="com.mysql.cj.jdbc.Driver";
			String dburl ="jdbc:mysql://localhost:3306/carrot?serverTimezone=UTC";
			String dbUser ="root";		String dbpasswd ="admin";
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			st.executeUpdate("update user set point=point+30 where nickname='"+nickname+"'");
		}catch(Exception e) {
			
		}
	}
	public void pointMinus(String nickname,String minus) {
		try {
			String jdbc_driver ="com.mysql.cj.jdbc.Driver";
			String dburl ="jdbc:mysql://localhost:3306/carrot?serverTimezone=UTC";
			String dbUser ="root";		String dbpasswd ="admin";
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			st.executeUpdate("update user set point=point-"+minus+" where nickname='"+nickname+"'");
		}catch(Exception e) {
			
		}
	}
}
