package coupon;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Coupon {
	String jdbc_driver ="com.mysql.cj.jdbc.Driver";
	String dburl ="jdbc:mysql://localhost:3306/carrot?serverTimezone=UTC";
	String dbUser ="root";		String dbpasswd ="admin";
	
	public int addCoupon(String nickname,String type) {
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			count=st.executeUpdate("insert into coupon (nickname,name) values('"
			+nickname+"','"
			+type+"'"
			+")");
		}catch(Exception e) {
			
		}
		return count;
	}
	
	public String countCoupon(String nickname) {
		String count = null;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			ResultSet rs =st.executeQuery("select count(*) as number from coupon where nickname='"+nickname+"'");
			rs.next();
			count = rs.getString("number");
		}catch(Exception e) {
			
		}
		return count;
			}
	
	public int deleteCoupon(String num) {
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			count=st.executeUpdate("delete from coupon where num="+num);
		}catch(Exception e) {
			
		}
		return count;
	}
	
	
}
