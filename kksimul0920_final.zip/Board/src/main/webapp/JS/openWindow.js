function openNewWindow(window) { 
open (window,"game"," width=800, height=800"); 

}