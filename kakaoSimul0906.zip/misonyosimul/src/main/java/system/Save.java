package system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Save {
	
	public int savePoint( String pageNum) {
		int count=0;
		try {
			String jdbc_driver ="com.mysql.cj.jdbc.Driver";
			String dburl ="jdbc:mysql://localhost:3306/lovestory?serverTimezone=UTC";
			String dbUser ="root";		String dbpasswd ="admin";
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			count=st.executeUpdate("insert into savepoint (storyNum,date) values('"+pageNum+"',now())");
			
		}catch(Exception e) {
			
		}
		return count;
	}
}
