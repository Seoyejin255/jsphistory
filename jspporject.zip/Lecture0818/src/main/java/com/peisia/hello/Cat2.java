package com.peisia.hello;

public class Cat2 {
	public String name;
}
