package jsp.question13_;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/q13_15/HelloCaT")//경로를 q14폴더의 HelloCaT으로 지정해줌.

public class HelloCat extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public HelloCat() {
        super();
    }
	public void init(ServletConfig config) throws ServletException {
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");		
		response.setContentType("text/html; charset=UTF-8"); // 안하면 한글 깨짐
		PrintWriter out = response.getWriter();
		String name=request.getParameter("name");
		String nickname=request.getParameter("nickname");
		out.print("이름 : " +name+" 닉네임 : "+ nickname);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
