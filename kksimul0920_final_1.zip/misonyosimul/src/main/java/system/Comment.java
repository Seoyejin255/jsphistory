package system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Comment {
	String jdbc_driver = "com.mysql.cj.jdbc.Driver";
	String dburl = "jdbc:mysql://localhost:3306/lovestory?serverTimezone=UTC";
	String dbUser = "root";
	String dbpasswd = "admin";

	public int countCmt(String num) {// 댓글을 세는 곳
		int totalCmt = 0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl, dbUser, dbpasswd);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select count(*) from board where boardNum=" + num);
			rs.next();
			totalCmt = rs.getInt("count(*)");
		} catch (Exception e) {

		}
		return totalCmt;
	}
	public int insertCmt(String nickname,String comment,String boardNum) {// 댓글을 세는 곳
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl, dbUser, dbpasswd);
			Statement st = conn.createStatement();
			count=st.executeUpdate("insert into board (date,nickname,comment,boardNum) values(now(),'"
			+nickname
			+"','"+comment
			+"',"+boardNum
			+")");
		} catch (Exception e) {

		}
		return count;
	}
	public String getCmt(String num) {// 댓글 갖고오는 곳.
		String str="";
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl, dbUser, dbpasswd);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from board where num="+num);
			rs.next();
			str=rs.getString("comment");
		} catch (Exception e) {
		}
		return str;
	}
	public int editCmt(String editNum,String comment) {
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			count=st.executeUpdate("update board set comment='"+comment+"',date=now() where num = "+editNum);
		}catch(Exception e) {
		}
		return count;
	}
	public int deleteCmt(String deleteNum) {
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			count=st.executeUpdate("delete from board where num="+deleteNum);
		}catch(Exception e) {
		}
		return count;
	}
}
