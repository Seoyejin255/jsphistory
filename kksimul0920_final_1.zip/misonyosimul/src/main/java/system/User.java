package system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class User {
	String jdbc_driver ="com.mysql.cj.jdbc.Driver";
	String dburl ="jdbc:mysql://localhost:3306/lovestory?serverTimezone=UTC";
	String dbUser ="root";		String dbpasswd ="admin";
	
	public ArrayList<String> findProfile(String nickname) {
		ArrayList<String> user = new ArrayList<>();
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from user where unickname='"+nickname+"'");
			rs.next();
			user.add(rs.getString("message"));
			user.add(rs.getString("imgUrl"));
		}catch(Exception e) {
			
		}
		return user;
	}
}
