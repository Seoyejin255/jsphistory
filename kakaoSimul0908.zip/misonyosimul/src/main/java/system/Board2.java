package system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Board2 {
	String jdbc_driver ="com.mysql.cj.jdbc.Driver";
	String dburl ="jdbc:mysql://localhost:3306/lovestory?serverTimezone=UTC";
	String dbUser ="root";		String dbpasswd ="admin";
	
	public int totalNum() {
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select count(*) from board");
			rs.next();
			count=rs.getInt("count(*)");
		}catch(Exception e) {
		}
		return count;
	}
}
