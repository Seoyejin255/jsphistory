package system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Board2 {
	String jdbc_driver ="com.mysql.cj.jdbc.Driver";
	String dburl ="jdbc:mysql://localhost:3306/lovestory?serverTimezone=UTC";
	String dbUser ="root";		String dbpasswd ="admin";
	
	public int totalNum() {
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select count(*) from board");
			rs.next();
			count=rs.getInt("count(*)");
		}catch(Exception e) {
		}
		return count;
	}
	public int insertBoard(String nickname , String title, String content) {
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			count=st.executeUpdate("insert into board (title, content,nickname,date) values('"
			+title+"','"
			+content+"','"
			+nickname+"',"
			+"now()"
			+")");
			}catch(Exception e) {
		}
		return count;
	}
	public int delteteBoard(String num) {
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			count=st.executeUpdate("delete from board where num ="+num);
		}catch(Exception e) {
		}
		return count;
	}
	
	public int editBoard(String title, String content,String num) {
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			count=st.executeUpdate("update board set title='"+title+"',content='"+content+"',date=now() where num = "+num);
		}catch(Exception e) {
		}
		return count;
	}
	
	public int recommend(String num) {
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			count=st.executeUpdate("update board set recommend=recommend+1 where num="+num);
		}catch(Exception e) {
		}
		return count;
	}
	public void view(String num) {
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			st.executeUpdate("update board set view=view+1 where num="+num);
		}catch(Exception e) {
		}
	}
	
}
