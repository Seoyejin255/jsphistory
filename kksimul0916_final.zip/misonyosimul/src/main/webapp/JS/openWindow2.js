function openNewWindow(window) { 
open (window,"Mail"," width=850, height=850"); 

}