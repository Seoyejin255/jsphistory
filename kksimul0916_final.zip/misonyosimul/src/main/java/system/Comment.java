package system;

public class Comment {

	public void countCmt(String num) {//댓글을 세는 곳
		try {
			
		}catch(Exception e) {
			
		}
	}
}
