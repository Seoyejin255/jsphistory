package system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Login {
	String jdbc_driver ="com.mysql.cj.jdbc.Driver";
	String dburl ="jdbc:mysql://localhost:3306/lovestory?serverTimezone=UTC";
	String dbUser ="root";		String dbpasswd ="admin";
	
	public int findLogin(String id , String pw){//로그인 처리.
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select count(*) from user where uid='"+id+"'&&upw='"+pw+"'");
			rs.next();
			count=rs.getInt("count(*)");
		}catch(Exception e) {
		}
		return count;
	}
	public String findNick(String id){//로그인 처리.
		String nickname=null;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from user where uid='"+id+"'");
			rs.next();
			nickname = rs.getString("unickname");
		}catch(Exception e) {
		}
		return nickname;
	}
}


