function openNewWindow(window) { 
open (window,"Mail"," width=800, height=800"); 

}