function add(str){
		var display = document.getElementById('display');
        display.value+=str;
	if(str=="="){
	//document.getElementById('s').value=s;
	//document.getElementById('s').value=n;
	alert(document.getElementById('s').value)
	alert(document.getElementById('n').value)
	document.getElementById('CalcForm').submit();
	
	}else if(str=="del"){
		document.getElementById('s').value="?";
		document.getElementById('n').value="?";
		display.value="";
	}else if(str=="C"){
		display.value="";
	}else if(str=="+" || str=="÷" || str=="%" || str =="x" || str =="-"){
		 if((document.getElementById('s').value)=="?"){
			document.getElementById('s').value="";
			document.getElementById("s").value+=str;
		}else{
			document.getElementById("s").value+=","+str;
		}
		document.getElementById('f').value="yes";
	}else{
		if((document.getElementById('f').value)=="yes"){
			if((document.getElementById('n').value)=="?"){
			document.getElementById("n").value="";
			document.getElementById("n").value+=str;	
			document.getElementById("f").value="no";
			}else{
			document.getElementById("n").value+=","+str;	
			document.getElementById("f").value="no";
			}
			
			
		}else if((document.getElementById('f').value)=="no"){
		document.getElementById("n").value+=str;
		}
	}
	
}
