var re_id, re_pw, re_pwr, re_nickname;//html에서 객체형식으로 받아 올 변수
var id, pw, pwr, nickname;// 폼 태그의 입력 값을 가져 올 변수.

window.onload = function () {
    re_id = document.getElementById("id");
    re_pw = document.getElementById("pw");
    re_pwr = document.getElementById("rpw");
    re_nickname = document.getElementById("nickname");
}
//alert(sex[0].value);-> 남자 alert(sex[1].value); -> 여자
//아이디, 암호, 암호재입력, 이름,이메일

function register() { // 버튼이 클릭되고 나서 실행할 것들.
    input();
    PwdCheck();
}

function input() {//변수에 값을 넣는 함수.
    id = re_id.value;
    pw = re_pw.value;
    pwr = re_pwr.value;
    nickname = reg_name.value;
}
function PwdCheck() {// 비밀번호와 비밀번호 재확인이 일치하는지 확인하고 콘솔에 기록을 남기는 함수.
    if (pw == pwr) {
        alert("비밀번호가 같스빈다");
    }else{
	alert("비밀번호가 다름빈다");
}
    
}